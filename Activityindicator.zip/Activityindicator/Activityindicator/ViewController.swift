//
//  ViewController.swift
//  Activityindicator
//
//  Created by Rp on 27/11/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var activityindicatorview : UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        activityindicatorview.startAnimating()
        activityindicatorview.frame = CGRect.init(x: 177, y: 60, width: 100, height: 100)
        activityindicatorview.activityIndicatorViewStyle = .gray
       // activityindicatorview.backgroundColor = UIColor.black
     //   activityindicatorview.tintColor = UIColor.white
        self.perform(#selector(self.stoploading), with: activityindicatorview, afterDelay: 5)
        
        let actvityindicatorSecound = UIActivityIndicatorView()
        actvityindicatorSecound.startAnimating()
        actvityindicatorSecound.frame = CGRect.init(x: 177, y: 260, width: 100, height: 100)
        actvityindicatorSecound.activityIndicatorViewStyle = .whiteLarge
        actvityindicatorSecound.backgroundColor = UIColor.white
        actvityindicatorSecound.color = UIColor.red
        self.perform(#selector(self.stoploadingOne), with: actvityindicatorSecound, afterDelay: 5)
        view.addSubview(actvityindicatorSecound)
        
        
    }
    
    @objc func stoploading(activity:UIActivityIndicatorView){
        activity.stopAnimating()
    }
    
    @objc func stoploadingOne(activity1:UIActivityIndicatorView){
        activity1.stopAnimating()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

